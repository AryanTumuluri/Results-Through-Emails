<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Automatic Results Sender</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-light bg-light">
        <a href="<?php $_SERVER["PHP_SELF"]?>" class="navbrand"><img src="images/logo.png" style="width:160px" alt=""></a>
    </nav>
    <div class="container">
        <div class="row">
        <img src="images/sender.gif" alt="" style="position:absolute;z-index:100;top:6vh;left:35vw;width:450px;display:none" class="loader">
            <div class="card col-md-6 offset-3 my-5">
                <h3 class="card-title text-center text-danger ">Send results</h3>
                <div class="card-body">
                <!-- select  batch -->
                    <select name="" id="batch" style="width:200px">
                        <option>--Select Batch--</option>
                        <?php
                           for($i=2015;$i<=date("Y");$i++){
                               $year=$i;
                               $next = $i+4;
                            ?>
                            <option value='<?php echo $year."-".$next?>'><?php echo $year." - ".$next?></option>
                            <?php
                           }
                        ?>
                    </select>
                    <!-- select semester -->
                    <select name="" id="sem">
                           <option value="" style="width:200px;margin-left:15px">--Select Semester--</option>
                           <?php
                           for($i=1;$i<9;$i++){
                               ?>
                                <option value="<?php echo $i?>"><?php echo "Semester-".$i?></option>
                               <?php
                           }
                           ?>
                    </select>
                    <!-- send button -->
                    <button class="btn btn-danger" style="margin-left:15px">Send Mail</button>
                </div>
                <div class="tmp"></div>
            </div>
        </div>
    </div>
    <script>
        $(".btn").click(function(){
            let sem = $("#sem").val();
            let batch = $("#batch").val();
            if(sem=="" || batch==""){
                alert("Select the details");
                return
            }
            $(".card").css("opacity",".4");
            $(".loader").css("display","block");
            $.ajax({
                url:"send.php?sem="+sem+"&batch="+batch,
                type:"GET",
                success:function(resp){
                    resp=resp.trim();
                  if(resp="sent"){
                    alert("Mail sent to the students");
                    $(".card").css("opacity","1");
                    $(".loader").css("display","none");
                  }else{
                    alert("Something wrong...");
                    $(".card").css("opacity","1");
                    $(".loader").css("display","none");
                  }
                }
            });
        });
    </script>
</body>
</html>