<?php
    if(isset($_GET['sem']) && isset($_GET['batch'])){
        $conn = mysqli_connect("localhost","dileep","dileep4242","resultsdb") or die("Unable to connect...");
        $sem = $_GET['sem'];
        $batch = $_GET['batch'];
        $check = array();
        $query = "SELECT vtu,stu_name FROM results WHERE sem='$sem' AND batch='$batch'";
        $res = mysqli_query($conn,$query);
        if(mysqli_num_rows($res)>0){
            while($row = mysqli_fetch_assoc($res)){
                $vtu = $row["vtu"];
                $name = $row["stu_name"];
                $err = false;
                for($i=0;$i<count($check);$i++){
                    if($vtu==$check[$i]){
                        $err = true;
                    }
                }
                array_push($check,$vtu);
                if($err==false){
                     // sending results...
                    $inner_query = "SELECT * FROM results WHERE sem='$sem' AND vtu='$vtu'";
                    $result = mysqli_query($conn,$inner_query);
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    $msg ="<table border='1' cellpadding='10' style='text-align:center'>
                            <tr>
                                <th>Course</th>
                                <th>Course Code</th>
                                <th>Grade</th>
                                <th>Result</th>
                                <th>Year of Pass</th>
                            </tr>";
                    while($data=mysqli_fetch_assoc($result)){
                            $course = $data["course"];
                            $code = $data["code"];
                            $grade = $data["grade"];
                            $etype = $data['etype'];
                            $yop = $data["yop"];
                            $to = strtolower($vtu)."@veltechuniv.edu.in";
                            $msg.="<tr style='padding:10px'>
                                <td width='200px'>$course</td>
                                <td width='200px'>$code</td>
                                <td width='100px'>$grade</td>
                                <td width='100px'>$etype</td>
                                <td width='100px'>$yop</td>
                            </tr>";
                    }
                    if(mail($to,"Veltech Semester Results",$msg,$headers)){
                        echo "sent";
                    }else{
                        echo "not sent";
                    }
               
                ?>
                    </table>
                <?php
                }
                
            }
        }
    }
    
?>